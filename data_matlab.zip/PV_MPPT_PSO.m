% HYBRID MPPT ALGORITHM FOR PV SYSTEMS UNDER PARTIALLY SHADED CONDITIONS
% USING A STOCHASTIC EVOLUTIONARY SEARCH AND A DETERMINISTIC HILL CLIMBING

%%  Keywords:    maximum power point tracking, photovoltaic system, hybrid part-stochastic
%%  part-deterministic search rule, particle swarm optimization, partial shading, hill climbing

% Karol Basinski and Bartlomiej Ufnalski
% Institute of Control and Industrial Electronics
% Warsaw University of Technology


function PV_MPPT_PSO(swarm_size,n_of_iter,...
    change_1,change_2,diversity_limit,evaporation_constant,velocity_clamping_min,velocity_clamping_max,grad,grad_step_min,grad_step_max,scenario)

%
% swarm_size = number of particles (typically 10--30)[*]
% n_of_iter = number of swarm iterations
% change --> irradiation change
% diversity_limit --> to prevent swarm stagnation
% evaporation_constant --> to gradually refresh memory of the swarm
% (typically 0.9--0.95 with evaporation rate growth mechanism)
% velocity_clamping --> to calm the swarm (typically 5--50)
% [*] these values refer to the discussed servo drive
%% Initialization
% Global parameters for the Simulink model
global pso_ctrl ir1 ir2 ir3     % reference voltage and irradiance for individual modules
global V1 V2 V3                 % modules voltage
%
rng('shuffle');
my_mdl = 'PV_string_model_partial_shading';
char_mdl= 'PV_charakterystyka'
load_system(my_mdl);
load_system(char_mdl);
load charakterystyka.mat


num_of_D = 1;

init_position=400;
init_speed=5;

grad_step_sl=0.01;
los=0;
licz=0;
evap_rate_growth_mechanism=1;          % 1: evaporation rate growth mechanism on, 0: off
evap_const_inc=0;
evap_const_inc_counter=1;
evaporation_const=evaporation_constant;
% Some declarations

history_evap_const=zeros(1,n_of_iter);
his_evap_const_inc=zeros(1,n_of_iter);
swarm_diversity = zeros(1,num_of_D);
swarm_dir = zeros(1,num_of_D);
gbest = 0;
his_gbest=zeros(1,n_of_iter);
objective_function = zeros(1,swarm_size);
Moc=zeros(n_of_iter,swarm_size);
Moc_sum=zeros(n_of_iter,1);
current_leader = 0;
V1=1;
V2=1;
V3=1;
% Summary (part 1)
disp(['Diversity limit: ',num2str(diversity_limit)]);
disp(['Evaporation rate: ',num2str(evaporation_constant)]);
%disp(['Velocity clamping: ',num2str(velocity_clamping)]);
% Tidying up
for i=1:2,
    try close(1); catch wiad; end
end
%


pso_ctrl = 0;    %[t ;[zeros(size(t,2))]]';

% Constricted PSO
correction_factor = 2.05;
Kappa=2/abs(2-2*correction_factor-sqrt((2*correction_factor)^2-8*correction_factor));
%
%% Initial swarm position and velocity
swarm=zeros(swarm_size,4,num_of_D);
for index=1:swarm_size,
    swarm(index, 1, :) = init_position*rand(num_of_D,1);
    swarm(index, 2, :) = init_speed*(rand(num_of_D,1)-0.5)*2;
end

swarm(:, 4, 1) = 0;  %  10e10;          % best value so far
ppos(:,1)=swarm(:,1,1);
%

%% The swarm is turned on
tic
for iter = 1 : n_of_iter,
    %scenario=1;
    %% 1 scenario
    if scenario==1
    if iter<change_1,
        ir1=1; 
        ir2=1;
        ir3=1;
    elseif iter<change_2,
        ir1=1; 
        ir2=0.6;
        ir3=0.3;
    else
        ir1=1; 
        ir2=1;
        ir3=1;
    end
    end
    %% 2 scenario
    if scenario==2
      if iter<change_1,
        ir1=1; 
        ir2=1;
        ir3=1;
      elseif iter<change_2,
        if iter<(change_1+17)
        ir1=ir1-0.005*10; 
        ir2=ir2-0.005*10;
        ir3=ir3-0.005*10;
        end
      %else
        if iter>(change_2-17),  
        ir1=ir1+0.005*10; 
        ir2=ir2+0.005*10;
        ir3=ir3+0.005*10;
        end
      else
        ir1=1; 
        ir2=1;
        ir3=1;
      end
    end
        %% 3 scenario
        if scenario==3,
      if iter<change_1,
        ir1=1; 
        ir2=1;
        ir3=1;
      elseif iter<change_2,
        if iter<(change_1+41)
        %ir1=ir1-0.005; 
        ir2=ir2-0.01;
        ir3=ir3-0.0175;
        end
      else
          if iter>(change_2+9)
        %ir1=ir1+0.005; 
        ir2=ir2+0.01;
        ir3=ir3+0.0175;
          end
      end
        end
        

        %% 4 scenario
        if scenario==4,
      if iter<change_1,
        ir1=1; 
        ir2=1;
        ir3=1;
      elseif iter<change_2,
        if iter<(change_1+21)
        %ir1=ir1-0.005; 
        ir2=ir2-0.01*2;
        ir3=ir3-0.0175*2;
        end
      else
          if iter>(change_2+19) && iter<(n_of_iter-9)
        %ir1=ir1+0.005; 
        ir2=ir2+0.01*2;
        ir3=ir3+0.0175*2;
          elseif iter>(n_of_iter-10)
        ir1=1; 
        ir2=1;
        ir3=1;      
          end
      end
        end  
        
    for n = 1 : swarm_size % this swarm uses the asynchronous update rule
        
        if n==1
            sim(char_mdl);
            Uchar(iter,:)=Uw;  % P-V characteristics acquisition 
            Ichar(iter,:)=Iw;
        end

        pso_ctrl=swarm(n,1,:);
        
        sim(my_mdl);
        % This is online process - the sytem is NOT started with zero
        % initial conditions
        V1=Vm1(max(size(Vm1)));
        V2=Vm2(max(size(Vm2)));
        V3=Vm3(max(size(Vm3)));
        % If the growth of evaporation rate mechanism
        % is activated for three iterations and uneven voltage on individual modules occurs (difference
        % between the highest and the lowest voltage is greater than 15 %), five consecutive
        % particles (excluding the current leader) are located randomly at a specified intervals
        if ((V1>=1.15*V2) || (V1>=1.15*V3) || (V2>=1.15*V3) || (V2>=1.15*V1) || (V3>=1.15*V2) || (V3>=1.15*V1)) && (evap_const_inc_counter==3) && (los==0)
           los=1;
        end
        U(iter,n)=Vm(max(size(Vm)));
        Moc(iter,n)=Vm(max(size(Vm)))*Im(max(size(Im)));  % PV system power
        I(iter,n)=Im(max(size(Im)));
        Moc_sum(iter)=Moc_sum(iter)+Moc(iter,n);
        disp(['iteration: ' num2str(iter),', particle: ' num2str(n),', Power= ' num2str(Moc(iter,n))...
            ,' Voltage= ' num2str(U(iter,n)),' V1= ' num2str(V1),' V2= ' num2str(V2),' V3= ' num2str(V3)])

        
        %% Visualisation
         if n == swarm_size,  
             Pchar=Uw.*Iw;
             Pw(iter)=max(Uw.*Iw);             
             plot(Uw,Pchar,'LineWidth',1.5)
             hold on
             for nn=1:(swarm_size-1)
                 %plot(ppos(nn,1,1),Moc(iter,nn),'ro','MarkerSize',5,'MarkerFaceColor','r')
                 plot(U(iter,nn),Moc(iter,nn),'ro','MarkerSize',5,'MarkerFaceColor','r')
             end
%              plot(swarm(n,1,1),Moc(iter,n),'ro','MarkerSize',5,'MarkerFaceColor','r')
               plot(U(iter,n),Moc(iter,n),'ro','MarkerSize',5,'MarkerFaceColor','r')
             axis([0 464 0 1400]);
             grid
             xlabel('Voltage [V]')
             ylabel('Power [W]')
             title(['iteration: ' num2str(iter) '/' num2str(n_of_iter)])
             hold off

            pause(0.1);
        end

        %% gradual evaporation
%           In the case of a relatively rapid decline
%           in average power for all particles (when power in i-th iteration is lower than 75% of power
%           in one of past 7 iterations), rate of evaporation grows exponentially
%           Rate of evaporation returns to its primary
%           form, the moment when any particle becomes new pbest .
        if n==1  && evap_rate_growth_mechanism==1
            if iter>7
                if Moc_sum(iter-1)<0.75*Moc_sum(iter-2) || Moc_sum(iter-1)<0.75*Moc_sum(iter-3) || Moc_sum(iter-1)<0.75*Moc_sum(iter-4) || Moc_sum(iter-1)<0.75*Moc_sum(iter-5) || Moc_sum(iter-1)<0.75*Moc_sum(iter-6) || Moc_sum(iter-1)<0.75*Moc_sum(iter-7)
                    evap_const_inc=1;
                  end
            end
            
            if evap_const_inc==1
                evap_const_inc_counter=evap_const_inc_counter+1;
            else
                evap_const_inc_counter=1;
            end
            evaporation_const=evaporation_constant^evap_const_inc_counter;
        end

        
         history_evap_const(iter)=evaporation_const;
         his_evap_const_inc(iter)=evap_const_inc;
        val = Moc(iter,n);% objective_function(n);
        swarm(n,5,1)=val;
        if val > swarm(n, 4, 1)*evaporation_const,
            for d=1:num_of_D,
                swarm(n, 3, d) = swarm(n, 1, d);
            end
            swarm(n, 4, 1) = val;
            evap_const_inc=0;
        else
            swarm(n, 4, 1)=swarm(n, 4, 1)*evaporation_const;
        end

        if n==swarm_size
            disp('--------------------------');
            disp(['evaporation rate = ' num2str(evaporation_const)]);
            disp('--------------------------');
            his_gbest(1,iter)=max(swarm(:,4,1));
        end        
        
        [~, gbest] = max(swarm(:, 4, 1)); % gbest
        [~, current_leader] = max(swarm(:, 5, 1));
        %% Diversity control
        % For more info on avoiding stagnation see:
        % J. Riget and J. S. Vesterstrom, "A diversity-guided particle swarm
        % optimizer - the ARPSO," Aarhus Universitet, Denmark, Tech. Rep., 2002.
        
        for d=1:num_of_D,
            swarm_diversity(d) = 0.5*(max(swarm(:, 1, d))-min(swarm(:, 1, d)));
        end
        
        
        for d=1:num_of_D,
            if swarm_diversity(d) < diversity_limit,
                swarm_dir(d) = -1;
            else
                swarm_dir(d) = 1;
            end
        end
        
        %% Updating velocity vectors and positions
   
% If a given particle is a current leader, the voltage pso_ctrl
% represented by that particle in the next iteration is
% determined by the HC method. A particle that is not a leader operates on
% the principle of the classical PSO
        
        ppos(n,iter)=swarm(n,1,1);
       if (n==current_leader) && (grad==1)
           disp(['Gotcha! Iteracja: ' num2str(iter) '. Cz�stka: ' num2str(n) '.']);
          if iter>1
              slope=abs((Moc(iter,n)-Moc(iter-1,n))/swarm(n,2,1));
              grad_step_sl=grad_step_max*slope/360*100;
              if grad_step_sl>grad_step_max
                  grad_step_sl=grad_step_max;
              elseif grad_step_sl<grad_step_min
                  grad_step_sl=grad_step_min;
              end
           if Moc(iter,n)>Moc(iter-1,n)
               swarm(n,2,1)=sign(swarm(n,2,1))*grad_step_sl;
               swarm(n,1,1)=swarm(n,1,1)+swarm(n,2,1);
           else
               swarm(n,2,1)=-sign(swarm(n,2,1))*grad_step_sl;
               swarm(n,1,1)=swarm(n,1,1)+swarm(n,2,1);
           end
          end 
       else
           
% If the growth of evaporation rate mechanism
% is activated for three iterations and uneven voltage on individual modules occurs (difference
% between the highest and the lowest voltage is greater than 15%), five consecutive
% particles (excluding the current leader) are located randomly at a specified intervals (in
% this case for model simulation, at 80 volts intervals). Other particles in this particular
% case operate according to conventional PSO (+ classic HC MPPT for the leader). This
% solution gives a chance to locate global maximum.
           
        if (los==1) && (licz<5)
            swarm(n,1,1)=(licz)*80+rand*80;
            licz=licz+1;
        else
            if (n==swarm_size) && (evap_const_inc==0)
            licz=0;
            los=0;
            end
        for d = 1 : num_of_D,
            % Different rand for each particle in each dimension
            rand1=rand;
            rand2=rand;
            swarm(n, 2, d) = Kappa*(swarm(n, 2, d)...
                + swarm_dir(d)*correction_factor*rand1*(swarm(n, 3, d) - swarm(n, 1, d))...
                + swarm_dir(d)*correction_factor*rand2*(swarm(gbest, 3, d) - swarm(n, 1, d)));
            % Velocity clamping
            velocity_clamp=velocity_clamping_min+abs(swarm(current_leader, 1, d) - swarm(n, 1, d));
            if velocity_clamp>velocity_clamping_max
                velocity_clamp=velocity_clamping_max;
            end
            swarm(n, 2, d)= min(max(-velocity_clamp,swarm(n, 2, d)),velocity_clamp);
            swarm(n, 1, d) = swarm(n, 1, d) + swarm(n, 2, d);
        end
        end
       end 
    end
end
close_system(my_mdl);
close_system(char_mdl);
disp('-------------------Finito!-------------------');
disp(['-------- Elapsed time is ' num2str(round(toc/60)) ' minutes. --------']);
figure(2)
iteracja=1:n_of_iter;
    plot(iteracja,Moc(:,1),'ro','MarkerSize',2,'MarkerFaceColor','r')
    hold on
    %plot(iteracja,his_gbest,'go','MarkerSize',2,'MarkerFaceColor','g')
    plot(iteracja,Pw,'go','MarkerSize',2,'MarkerFaceColor','g')
    for n=2:swarm_size
    plot(iteracja,Moc(:,n),'ro','MarkerSize',2,'MarkerFaceColor','r')
    end
    %plot(iteracja,his_gbest,'go','MarkerSize',2,'MarkerFaceColor','g'),grid
    plot(iteracja,Pw,'go','MarkerSize',2,'MarkerFaceColor','g'),grid
    xlabel('Iteration')
    ylabel('Power [W]')
    legend('particles','Global MPP')
    hold off
%     save pomiary5_2 Moc U I Pw ppos Uchar Ichar history_evap_const his_evap_const_inc
return



% That's all folks! Enjoy an evolutionary dynamic optimization (EDO) of control
% signals in your systems!
